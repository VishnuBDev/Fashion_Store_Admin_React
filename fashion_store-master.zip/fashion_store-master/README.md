FASHION STORE ASSIGNMENT
1. Create a fashion store for the owner where he/she can maintain the stock of all clothes. As an
owner he/she should be able to do the following things –
    a. Should be able to add a clothing, which has a unique dresscode(eg-FS-001), brand(eg -
        LEVIS), Gender – Male/Female, type – (Shirt/Top/Jeans/Trousers/etc) price and stock(quantity).
    b. Should be able to update (updation form should be pre-filled) and delete a particular clothing.
    c. Should be able to list all the clothing.
    d. Should be able to see the current value of all the clothes in the store combined(net worth of the store).
    e. Should be able to sort the clothes based on price.
    f. Should be able to filter clothes, on different properties –
        i. Gender
        ii. Type
        iii. Brand
        iv. In Stock (Out of stock means, quantity = 0)
Note – Visualize the UI on your own and come up with a nice user experience flow. Should be responsive
for mobile views.
Use following - React, React Router, React Redux, Material UI