export const INITIAL_STATE={
      product:{
            id:'',
            brand:'',
            type:'',
            price:'',
            quantity:'',
            gender:''
      },
      list:[],
      current:'',
      selected:''


};

export const ADDBRAND='addBrand';
export const ADDPRICE='addprice';
export const ADDQUANTITY='addQuantity';
export const ADDTYPE='addtype';
export const ADDTOLIST='addtolist';
export const ADDGENDER='addgender';
export const CURRENTID='currentID';
export const ADDTOPRODUCT='addtoproduct';
export const EDITBRAND='editbrand';
export const SORT='sort';
export const DELETE='delete';