
import { INITIAL_STATE , ADDBRAND, ADDTYPE, ADDQUANTITY, ADDPRICE,ADDTOLIST, ADDGENDER, CURRENTID,ADDTOPRODUCT, SORT,DELETE,EDITBRAND} from "../constants/storeConstants";

export const rootReducer = (state=INITIAL_STATE,action) => {
  switch(action.type){
    case ADDBRAND:{
      return { ...state,product: {...state.product,
          id: Date.now(),
          brand: action.payload
        }
      }
    }
    case ADDTYPE:{
      return { ...state,
        product: {
          ...state.product,
          type: action.payload
        }
      }
    }
    case ADDQUANTITY:{
      return {...state,product:{...state.product,quantity:action.payload}}
    }

    case ADDPRICE:{
      return {...state,product:{...state.product,price:action.payload}}
    }

    case ADDGENDER:{
      return {...state,product:{...state.product,gender:action.payload}}
    }

    case ADDTOLIST:{
      return { ...state,
        list: [...state.list,state.product],
        product:INITIAL_STATE.product
      } 
    }

    case CURRENTID:{
      return {...state,current:action.payload}
    }

    case SORT:{
      return {...state,selected:action.payload}
    }

    case DELETE:{
      return {...state,list:action.payload}
    }

    case ADDTOPRODUCT:{
      return{...state,product:action.payload}
    }

    case EDITBRAND:{
      return {...state,product:{...state.product,brand:action.payload}}
    }
    
    // case PBYIDTOPRODUCT:{
    //   return {...state,product:{...state.product,
    //     id:action.payload.id,
    //     brand:action.payload.brand,
    //     type:action.payload.type,
    //     gender:action.payload.gender,
    //     price:action.payload.price,
    //     quantity:action.payload.quantity
    //   }}
    // }
    
    default:return state
  }
}