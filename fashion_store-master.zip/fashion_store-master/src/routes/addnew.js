import * as React from 'react';
import TextField from '@mui/material/TextField';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import Button from '@mui/material/Button';
import { useDispatch } from 'react-redux';
import { ADDBRAND , ADDPRICE, ADDQUANTITY, ADDTOLIST, ADDTYPE, ADDGENDER} from '../store/constants/storeConstants';
import { useSelector } from 'react-redux';

export default function Addnew(){

  
  const dispatch = useDispatch();
  //const list = useSelector((state)=>state.list);
  const product = useSelector((state)=>state.product);
   //console.log(list)
  // console.log(product)


  return(
  <div>
    <h1>Add new Product</h1>
    <form>
      <TextField  label="Brand" variant="outlined" value={product.brand} onChange={(e)=>dispatch({type:ADDBRAND,payload:e.target.value})}/><br/><br/>
      <TextField  label="Type" variant="outlined" value={product.type}  onChange={(e)=>dispatch({type:ADDTYPE,payload:e.target.value})}/><br/><br/>
      <TextField type="number" label="Price" variant="outlined" value={product.price} onChange={(e)=>dispatch({type:ADDPRICE,payload:e.target.value})}/><br/><br/>
      <TextField type="number" label="Quantity" variant="outlined" value={product.quantity} onChange={(e)=>dispatch({type:ADDQUANTITY,payload:e.target.value})}/><br/><br/>
      <FormControl component="fieldset">
        <FormLabel component="legend">Gender</FormLabel>
        <RadioGroup row
          aria-label="gender"
          value={product.gender}
          onChange={(e)=>dispatch({type:ADDGENDER,payload:e.target.value})}
          name="row radio-buttons-group"
        >
          <FormControlLabel value="female" control={<Radio />} label="Female" />
          <FormControlLabel value="male" control={<Radio />} label="Male" />
        </RadioGroup>
      </FormControl><br/><br/>
      <Button variant="contained" size="large" onClick={()=>dispatch({type:ADDTOLIST,payload:""})}>Add Product</Button>
    </form>
  </div>

  )
  
}