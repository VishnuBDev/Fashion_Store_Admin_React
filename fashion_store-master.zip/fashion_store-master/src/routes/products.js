import * as React from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { useDispatch, useSelector } from "react-redux";
import { Button } from '@mui/material';
import {  useNavigate } from 'react-router-dom';
import { CURRENTID, DELETE, SORT } from '../store/constants/storeConstants';
import { useState } from 'react';


export default function BasicTable() {
  const navigate=useNavigate();
  const dispatch=useDispatch();
  const listFetched=useSelector((state)=>state.list);
  const genderItems=[...new Set(listFetched.map(p=>p.gender))];
  const brandItems=[...new Set(listFetched.map(p=>p.brand))];
  const typeItems=[...new Set(listFetched.map(p=>p.type))];

  const [list,setList]=useState(listFetched);
  //for filter
  const [genderValue,setGenderValue]=useState('');
  const [brandValue,setBrandValue]=useState('');
  const [typeValue,setTypeValue]=useState('');
  const [quantityValue,setQuantityValue]=useState('');
  
  const selected=useSelector((state=>state.selected));
  
  React.useEffect(() => {
    setList(listFetched)
  }, [listFetched])
 

  const handleChange=(sortbyvalue)=>{
    dispatch({type:SORT,payload:sortbyvalue})
    const l=listFetched
    if(sortbyvalue==='Low to High'){
      setList( l.sort((a,b)=>{return a.price - b.price }));
    }else{
      setList( l.sort((a,b)=>{return b.price - a.price }));
    }
  }
  
  const toEditPage=(id)=>{
    dispatch({type:CURRENTID,payload:id});
    navigate("/Edit");
  }

  const deleteThis=(id)=>{
    
    const l=listFetched
    dispatch({type:DELETE,payload:(l.filter((product)=>product.id!==id))})


  }

  const filterGender=(filterbyvalue)=>{
    setGenderValue(filterbyvalue);
    const l=listFetched
    if(filterbyvalue==='None')
    {setList(l)}
    else
    {setList(l.filter(product=>product.gender===filterbyvalue))}
  }

  const filterBrand=(filterbyvalue)=>{
    setBrandValue(filterbyvalue);
    const l=listFetched
    if(filterbyvalue==="None")
    {setList(l)}
    else
    {setList(l.filter(product=>product.brand===filterbyvalue))}
  }

  const filterType=(filterbyvalue)=>{
    setTypeValue(filterbyvalue);
    const l=listFetched;
    if(filterbyvalue==="None")
    {setList(l)}
    else
    {setList(l.filter(product=>product.type===filterbyvalue))}
  }

  const filterQuantity=(filterbyvalue)=>{
    setQuantityValue(filterbyvalue);
    const l=listFetched;
    if(filterbyvalue==="In Stock")
    {setList(l.filter(product=>product.quantity>0))}
    else if(filterbyvalue==="Out of Stock")
    {setList(l.filter(product=>product.quantity==='0'))}
    else{setList(l)}
  }
  return (
    <>
   
    <h1>Product List</h1>
  <FormControl  sx={{ m: 1, minWidth: 150 }}>
  <InputLabel id="demo-simple-select-label">Sort By Price</InputLabel>
  <Select
    labelId="demo-simple-select-label"
    id="demo-simple-select"
    label="Sort By Price"
    value={selected}
    onChange={
      (e)=>handleChange(e.target.value)}
  >
    <MenuItem value="Low to High">Low to High</MenuItem>
    <MenuItem value="High to Low">High to Low</MenuItem>
    
  </Select>
  </FormControl><br/>

  {/* FILTER */}

  <FormControl  sx={{ m: 1, minWidth: 175 }}>
  <InputLabel >Filter By Gender</InputLabel>
  <Select
    label="Filter By Gender"
     value={genderValue}
    onChange={
      (e)=>filterGender(e.target.value)}
  >
    {
    genderItems.map(item=>
      <MenuItem key={item} value={item}>{item}</MenuItem>
    )} 
    <MenuItem key="Nogender" value="None">None</MenuItem>
  </Select>
  </FormControl>

  <FormControl  sx={{ m: 1, minWidth: 175 }}>
  <InputLabel >Filter By Brand</InputLabel>
  <Select
    label="Filter By Brand"
    value={brandValue}
    onChange={
      (e)=>filterBrand(e.target.value)}
  >
    {
    brandItems.map(product=>
      <MenuItem key={product} value={product}>{product}</MenuItem>
      )}
    <MenuItem key="Nobrand" value="None">None</MenuItem>
    
    
  </Select>
  </FormControl>

  <FormControl  sx={{ m: 1, minWidth: 175 }}>
  <InputLabel >Filter By Type</InputLabel>
  <Select
    label="Filter By Type"
    value={typeValue}
    onChange={
      (e)=>filterType(e.target.value)}
  >
    {typeItems.map(product=>
    <MenuItem key={product} value={product}>{product}</MenuItem>
    )}
    <MenuItem key="notype" value="None">None</MenuItem>
  </Select>
  </FormControl>

  <FormControl  sx={{ m: 1, minWidth: 175 }}>
  <InputLabel >Filter By Quantity</InputLabel>
  <Select
    label="Filter By Quantity"
    value={quantityValue}
    onChange={
      (e)=>filterQuantity(e.target.value)}
  >

    <MenuItem key="instock" value="In Stock">In Stock</MenuItem>
    <MenuItem key="outofstock" value="Out of Stock">Out of Stock</MenuItem>
    <MenuItem key="nofilter" value="None">None</MenuItem>
  </Select>
  </FormControl>



    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 300 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Product ID</TableCell>
            <TableCell align="right">Brand</TableCell>
            <TableCell align="right">Type</TableCell>
            <TableCell align="right">Gender</TableCell>
            <TableCell align="right">Price </TableCell>
            <TableCell align="right">Quantity</TableCell>
            <TableCell align="right">Update</TableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
          {list.map((row) => (
            <TableRow
              key={row.id}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.id}
              </TableCell>
              <TableCell align="right">{row.brand}</TableCell>
              <TableCell align="right">{row.type}</TableCell>
              <TableCell align="right">{row.gender}</TableCell>
              <TableCell align="right">{row.price}</TableCell>
              <TableCell align="right">{row.quantity}</TableCell>
              <TableCell align="right">
                <Button variant="outlined" onClick={()=>toEditPage(row.id)}>Edit</Button>&nbsp;
                <Button variant="outlined" onClick={()=>deleteThis(row.id)}>Delete</Button>
                </TableCell>
              
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </>
  );
}
