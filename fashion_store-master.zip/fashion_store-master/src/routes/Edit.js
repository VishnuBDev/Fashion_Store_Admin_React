import * as React from 'react';
import TextField from '@mui/material/TextField';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import Button from '@mui/material/Button';
import { useDispatch } from 'react-redux';
import { ADDTOPRODUCT,  ADDPRICE, ADDQUANTITY, ADDTOLIST, ADDTYPE, ADDGENDER,EDITBRAND, DELETE} from '../store/constants/storeConstants';
import { useSelector } from 'react-redux';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Edit(){
  const navigate=useNavigate();
  const dispatch = useDispatch();
  const listFetched=useSelector((state)=>state.list);
  const currID = useSelector((state)=>state.current);
  const productByID = useSelector((state)=>state.list).filter(element=>element.id===currID)[0];
  useEffect(()=>{
  dispatch({type:ADDTOPRODUCT,payload:productByID})
  },[]);
  const  product = useSelector((state)=>state.product);
 
  const editThis=()=>{
    const l=listFetched
    dispatch({type:DELETE,payload:(l.filter(prod=>prod.id!==currID))})
    dispatch({type:ADDTOLIST,payload:""})
    navigate('/Products');
  }
  
 
return(
  <>
  <h1>Edit item</h1>
  <form>
      <TextField  label="Brand" variant="outlined" value={product.brand} onChange={(e)=>dispatch({type:EDITBRAND,payload:e.target.value})}/><br/><br/>
      <TextField  label="Type" variant="outlined" value={product.type}  onChange={(e)=>dispatch({type:ADDTYPE,payload:e.target.value})}/><br/><br/>
      <TextField type="number" label="Price" variant="outlined" value={product.price} onChange={(e)=>dispatch({type:ADDPRICE,payload:e.target.value})}/><br/><br/>
      <TextField type="number" label="Quantity" variant="outlined" value={product.quantity} onChange={(e)=>dispatch({type:ADDQUANTITY,payload:e.target.value})}/><br/><br/>
      <FormControl component="fieldset">
        <FormLabel component="legend">Gender</FormLabel>
        <RadioGroup row
          aria-label="gender"
          value={product.gender}
          onChange={(e)=>dispatch({type:ADDGENDER,payload:e.target.value})}
          name="row radio-buttons-group"
        >
          <FormControlLabel value="female" control={<Radio />} label="Female" />
          <FormControlLabel value="male" control={<Radio />} label="Male" />
        </RadioGroup>
      </FormControl><br/><br/>
      <Button variant="contained" size="large" onClick={()=>editThis()}>UPDATE PRODUCT</Button>
    </form>
    </>
)
}