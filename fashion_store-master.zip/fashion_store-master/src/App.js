import logo from './logo.svg';
import './App.css';
import ResponsiveAppBar from './components/Navbar';
import { Routes } from 'react-router-dom';
import { Route } from 'react-router-dom';
import Addnew from './routes/addnew';
import Products from './routes/products';
import Edit from './routes/Edit';

function App() {
  return (
    <div className="App">
    
      <Routes>
        <Route path="/" element={< ResponsiveAppBar/>}>
        <Route path="Addnew" element={<Addnew/>}></Route>
        <Route path="/Products" element={<Products/>}></Route>
        <Route path="/Edit" element={<Edit/>}></Route>
        </Route>
      </Routes>
    </div>
  );
}

export default App;
